#! /usr/bin/env python3

from klassez import *
from pathlib import Path

def gen_string(filename):

    title_str = filename.upper()+ ' module'
    dashes = '=' * len(title_str)

    title = '\n'.join([title_str, dashes, '\n'])
    contents = '\n'.join([
        '.. contents::',
        '   :local:',
        ''])
    automodule_dir = f'.. automodule:: t1ttune.scripts.{filename}'
    extra_automodule = '\n'.join([
        '   :members:',
        '   :undoc-members:',
        '   :show-inheritance:'])

    whole_string = '\n'.join([title, contents, automodule_dir, extra_automodule])
    return whole_string

basedir = Path(__file__).parent


index_file = Path(__file__).parent / 'docmodules.rst'
names = []
for filename in basedir.iterdir():
    if filename.is_dir():
        continue
    if filename.name.startswith('.'):
        continue
    if 'qqq' in filename.name:
        continue
    tmp_doc = gen_string(filename.stem)
    names.append(filename.stem)

    filename.with_suffix('.rst').write_text(tmp_doc)
#index_file.write_text('\n'.join(['    '+w for w in names]))
